<div class="block lg:hidden mb-4">
    <button
        onclick="window.history.back()"
        class="flex items-center text-sm text-gray-500 hover:text-primary-500"
    >
        <x-heroicon-s-chevron-left class="w-4 h-4 mr-1" />
        Quay lại
    </button>

    <div class="mt-2 text-2xl font-bold">
{{--        {{ $this->getTitle() ?? $this->getHeading() }}--}}
    </div>
</div>
